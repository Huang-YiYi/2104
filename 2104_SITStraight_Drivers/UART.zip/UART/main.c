#include "msp.h"
#include <stdio.h>

char rx_buffer[1];

void UART2_init(void);
void delayMs(int n);

int check = 3;

void main(void) {

    UART2_init();

    SCB->SCR |= (SCB_SCR_SLEEPDEEP_Msk);
    SCB->SCR |= SCB_SCR_SLEEPONEXIT_Msk;
    __DSB();
    __sleep();
    __no_operation();

//    while(1){
//        while(!(EUSCI_A0->IFG & 0x02)){}
//        EUSCI_A0->TXBUF = 'Y';
//        while(!(EUSCI_A0->IFG & 0x02)){}
//        EUSCI_A0->TXBUF = 'e';
//        while(!(EUSCI_A0->IFG & 0x02)){}
//        EUSCI_A0->TXBUF = 's';
//        delayMs(2);
//    }


}


void sendDataHC05(char *data) {
    int i;
    for (i = 0; i < strlen(data); i++) {
        while (!(EUSCI_A2->IFG & 0x02)) {}
        EUSCI_A2->TXBUF = data[i];
    }
}

void UART2_init(void) {


    P3->SEL0 |= (BIT2 + BIT3);
    P3->SEL1 &= ~(BIT2 + BIT3);


    /*UART A2 is used for the HC-05*/
    EUSCI_A2->CTLW0 |= 1; /*put in reset mode for config*/
    EUSCI_A2->MCTLW = 0; /*disable over sampling*/
    EUSCI_A2->CTLW0 = 0x0081; /*1 stop bit, no parity, SMCLK, 8-bit data*/
    EUSCI_A2->BRW = 312; /*3,000,000 / 9600 = 312.5 take the whole*/
    EUSCI_A2->CTLW0 &= ~1; /*take UART out of reset mode*/

    P1->SEL0 |= 0x0C;
    P1->SEL1 &= ~0x0C;

    /*We are using UART A0 for UART PC*/
//    EUSCI_A0->CTLW0 |= 1; /*put in reset mode for config*/
//    EUSCI_A0->MCTLW = 0; /*disable over sampling*/
//    EUSCI_A0->CTLW0 = 0x0081; /*1 stop bit, no parity, SMCLK, 8-bit data*/
//    EUSCI_A0->BRW = 26; /*3,000,000 / 115200 = 26.0416*/
//    EUSCI_A0->CTLW0 &= ~1; /*take UART out of reset mode*/

    EUSCI_A2->IE |= UCRXIE;
    NVIC->ISER[0] |= 1 << ((EUSCIA2_IRQn) & 31);
    __enable_irq();

    sendDataHC05("Welcome to sitStraight");
    sendDataHC05("Enter User Config");

}

void EUSCIA2_IRQHandler(void) {

    if (UCA2IFG & UCRXIFG)
    {
        //rx_buffer[0] = UCA2RXBUF;
        //sendDataHC05(rx_buffer);
        switch(UCA2RXBUF)
               {
                   case 1:
                       checkAngles();
                       break;
                   case 2:
                       sendDataHC05("You sent b");
                       break;
                   case 3:
                       sendDataHC05("You sent c");
                       break;
                   case 4:
                       sendDataHC05("You sent d");
                       break;
                   default:
                       sendDataHC05("Unknown Command: ");

                       break;
               }

        printf(rx_buffer);

        UCA2IFG &= ~UCRXIFG;
    }
}

//void checkAngles(void){
//    while(1){
//    sendDataHC05("122");
//    }
//}

/* delay milliseconds when system clock is at 3 MHz */
void delayMs(int n) {
    int i, j;
    for (j = 0; j < n; j++)
        for (i = 750; i > 0; i--);      /* Delay */
}

