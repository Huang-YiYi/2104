/*
 * Copyright (c) 2016-2019, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *    ======== i2cmasterexample1.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include "ti_drivers_config.h"
#include <ti/drivers/I2C.h>
#include "msp.h"
#include <SITStraight.h>
uint8_t fs_sel = 3; //Gyro split
uint8_t afs_sel = 3;//accel split

uint8_t txBuffer[10];
static uint8_t rxBuffer[20];



I2C_Handle      i2c;
I2C_Params      i2cParams;
I2C_Transaction i2cTransaction;

void i2cWrite(I2C_Handle i2c, uint8_t slaveAddr, uint8_t regAddr, uint8_t value)
{
    bool retVal = 0;
    txBuffer[0] = regAddr; //register addr
    txBuffer[1] = value; //data
    i2cTransaction.slaveAddress = slaveAddr;
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 2;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    do {
        retVal = I2C_transfer(i2c, &i2cTransaction);
    } while(!retVal);
}

uint8_t* i2cRead(I2C_Handle i2c, uint8_t slaveAddr, uint8_t regAddr, uint8_t len)
{
    bool retVal = 0;
    txBuffer[0] = regAddr; //register addr
    i2cTransaction.slaveAddress = slaveAddr;
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = len;
    do {
        retVal = I2C_transfer(i2c, &i2cTransaction);
    } while(!retVal);

    return rxBuffer;
}

void delayMs(int n){
    int i;
    TIMER32_1 -> LOAD = 3000 - 1;
    TIMER32_1 -> CONTROL = 0xC2;

    for (i=0; i < n; i ++){
        while ((TIMER32_1->RIS & 1) == 0 ){
        }
        TIMER32_1->INTCLR = 0;
    }


}


int16_t convert8to16(uint8_t val1, uint8_t val2)
{
    return (int16_t) (((uint16_t) val1 << 8) | ((uint16_t) val2));
}

int power(int base, int exponent)
{
    int result = 1;
    int var;
    for (var = 0; var < exponent; ++var) {
        result *= base;
    }
    return result;
}
void setRegister(uint8_t regAddr, uint8_t value)
{
    i2cWrite(i2c, MPU_ADDR, regAddr, value);
}
uint8_t getRegister(uint8_t regAddr)
{

    return i2cRead(i2c, MPU_ADDR, regAddr, 1)[0];
}

int16_t get1Axis(uint8_t regAddr)
{
    uint8_t* buf = i2cRead(i2c, MPU_ADDR, regAddr, 2);
    return convert8to16(buf[0], buf[1]);
}

int16_t* get3Axis(uint8_t regAddr)
{
    uint8_t* buf = i2cRead(i2c, MPU_ADDR, regAddr, 6);
    static int16_t xyz[3];
    xyz[0] = convert8to16(buf[0], buf[1]);
    xyz[1] = convert8to16(buf[2], buf[3]);
    xyz[2] = convert8to16(buf[4], buf[5]);
    return xyz;
}
float getTemp()
{
    return (1.0 * get1Axis(TEMP)/340 + 36.53);
}

int16_t* getGyro()
{
    return get3Axis(GYRO);
}

int16_t* getAccel()
{
    return get3Axis(ACCEL);
}

void MPUinit()
{
    //Init and set params for I2C
    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_100kHz;
    i2c = I2C_open(0, &i2cParams);

    //Power Cycle the MPU w/ VCC on P6.0
    P6DIR = 0;
    P6OUT = 0;
    delayMs(5000);
    P6DIR = 1;
    P6OUT = 1;
    delayMs(5000);


    //Wake up MPU
    setRegister(POWER_MGMT_1, 0x40); //reset to default values
    delayMs(100);
    setRegister(POWER_MGMT_1, 0x00); //clear sleep bit
    delayMs(100);
    setRegister(POWER_MGMT_1, 0x01); //use internal gyro clock
    uint8_t whoami = getRegister(WHOAMI);
    printf("whoami = %x\n", whoami);

}

void *mainThread(void *arg0)
{
    MPUinit();
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;
    float temp = getTemp();
    printf("temp(C) = %.2f\n", temp);

    while(1)
    {
        int16_t* gyro = getGyro();
        printf("gyro XYZ = %d %d %d\n", gyro[0]/16, gyro[1]/16, gyro[2]/16);
        int16_t* accel = getAccel();
        printf("accel XYZ = %d %d %d\n", accel[0]/2048, accel[1]/2048, accel[2]/2048);

        delayMs(1000);
    }
    return 0;
}

