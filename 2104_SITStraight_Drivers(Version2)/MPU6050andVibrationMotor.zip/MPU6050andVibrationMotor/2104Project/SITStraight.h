/*
 * test.h
 *
 *  Created on: 20 Oct 2019
 *      Author: jameswong
 */

#ifndef SITStraight_H_
#define SITStraight_H_

#include <stdint.h>
#include <ti/drivers/I2C.h>
void delayMs(int n);
//void wait(int n);
int16_t convert8To16(uint8_t val1, uint8_t val2);
int power(int base, int exponent);

#define MPU_ADDR 0x68
#define TEMP 0x41
#define GYRO 0x43
#define ACCEL 0x3B
#define POWER_MGMT_1 0x6B
#define WHOAMI 0x75

void i2cWrite(I2C_Handle i2c, uint8_t slaveAddr, uint8_t regAddr, uint8_t value);
uint8_t* i2cRead(I2C_Handle i2c, uint8_t slaveAddr, uint8_t regAddr, uint8_t len);

void setRegister(uint8_t regAddr, uint8_t value);
uint8_t getRegister(uint8_t regAddr);

int16_t get1Axis(uint8_t regAddr);
int16_t* get3Axis(uint8_t regAddr);

//GET SENSORS
float getTemp();
int16_t* getGyro();
int16_t* getAccel();

//STARTUP
void MPUinit();




#endif /* SITStraight_H_ */
