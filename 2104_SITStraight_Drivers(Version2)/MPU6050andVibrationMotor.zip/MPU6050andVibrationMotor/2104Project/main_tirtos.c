/*
 * Copyright (c) 2016-2019, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,

 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== main_tirtos.c ========
 */
#include <stdint.h>
#include "msp.h"
/* POSIX Header files */
#include <pthread.h>
#include <SITStraight.h>

/* RTOS header files */
#include <ti/sysbios/BIOS.h>

/* Driver configuration */
#include <ti/drivers/Board.h>

extern void *mainThread(void *arg0);

/* Stack size in bytes */
#define THREADSTACKSIZE    1024

/*
 *  ======== main ========
 */
#define PERIOD 186 // to generate a period signal of ~ 1ms
#define DELAY 20
//void delayMs(int n);
int c = 1000;
int upperbound = 3000;
int lowerbound = 100;
volatile int count;
void(*TimerA0Task)(int delay);
void PWM_Init(uint16_t period, uint16_t period_on) {

    P2->DIR = BIT5; // Selectig P2.4 as output
    P2->SEL0 |= BIT5; //Asociating Timer0A function to P2.4 pin
    P2->SEL1 &= ~BIT5;

    TIMER_A0->CTL = TIMER_A_CTL_SSEL__SMCLK | // SMCLK
                    TIMER_A_CTL_ID__8 | // /8
                    TIMER_A_CTL_MC__UPDOWN; // Up/Down mode

    TIMER_A0->CCTL[0] = TIMER_A_CCTLN_OUTMOD_4; // OUTMOD:Toggle
    TIMER_A0->EX0 = TIMER_A_EX0_IDEX__1; //input CLK divider /1;
    TIMER_A0->CCR[0] = period;
    TIMER_A0->CCTL[1] = TIMER_A_CCTLN_OUTMOD_2; // OUTMOD:Toggle/Reset
    TIMER_A0->CCR[1] = period_on;
}
void Vibration_Init(void) {
    P2->DIR = BIT5; //Selecting pin 2.4 as OUTPUT
    P2->OUT = BIT5;
}
void Toggle_Vibration(int delay) {
    count ++;
    if (count > delay){
        P2->OUT ^= BIT5;
        count = 0;
    }
}
void TimerA0_Init(void(*task) (int delay), uint16_t period) {

    TimerA0Task = task;

    TIMER_A0->CTL &= ~TIMER_A_CTL_MC_MASK;
    TIMER_A0->CTL = TIMER_A_CTL_SSEL__SMCLK | // SMCLK
                    TIMER_A_CTL_ID__8 | // /8
                    TIMER_A_CTL_MC__STOP | // Stop mode
                    TIMER_A_CTL_IE; // Interrupt enable

    TIMER_A0->CCTL[0] = TIMER_A_CCTLN_CM__NONE | //No capture mode
                        TIMER_A_CCTLN_CCIE; //Capture/Compare interrupt enable

    TIMER_A0->CCR[0] = (period - 1);
    TIMER_A0->EX0 &= TIMER_A_EX0_IDEX__1;;  // input clock divider /1
    NVIC->IP[2] = (NVIC->IP[2] & 0xFFFFFF00) | 0x00000040; // priority 2
    NVIC->ISER[0] = 0x00000100; // enable interrupt 8 in NVIC
    TIMER_A0->CTL |= TIMER_A_CTL_CLR | //reset the Timer
                     TIMER_A_CTL_MC_1; // start Timer A0 in up mode

}
int main(void)
     {
    pthread_t           thread;
    pthread_attr_t      attrs;
    struct sched_param  priParam;
    int                 retc;
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;
    Vibration_Init();
    TimerA0_Init(&Toggle_Vibration, PERIOD);
    /* Call driver init functions */
    Board_init();

    /* Initialize the attributes structure with default values */
    pthread_attr_init(&attrs);

    /* Set priority, detach state, and stack size attributes */
    priParam.sched_priority = 1;
    retc = pthread_attr_setschedparam(&attrs, &priParam);
    retc |= pthread_attr_setdetachstate(&attrs, PTHREAD_CREATE_DETACHED);
    retc |= pthread_attr_setstacksize(&attrs, THREADSTACKSIZE);
    if (retc != 0) {
        /* failed to set attributes */
        while (1) {}
    }

    retc = pthread_create(&thread, &attrs, mainThread, NULL);
    if (retc != 0) {
        /* pthread_create() failed */
        while (1) {}
    }

    BIOS_start();

    return (0);
}
void TA0_0_IRQHandler(void) {
    TIMER_A0->CCTL[0] &= ~TIMER_A_CTL_IFG;
    (*TimerA0Task)(DELAY);
}

void PORT1_IRQHandler(void){
    if(P1IFG & BIT1){
        c  -= 100;
        P1IFG &= ~BIT1;
    }
    if (P1IFG & BIT4){
        c  += 100;
        P1IFG &= ~BIT4;
    }
}
//void delayMs(int n){
//    int i;
//    TIMER32_1 -> LOAD = 3000 - 1;
//    TIMER32_1 -> CONTROL = 0xC2;
//
//    for (i=0; i < n; i ++){
//        while ((TIMER32_1->RIS & 1) == 0 ){
//        }
//        TIMER32_1->INTCLR = 0;
//    }
//
//
//}
