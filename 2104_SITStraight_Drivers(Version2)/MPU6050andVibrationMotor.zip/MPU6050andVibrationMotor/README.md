# ICT2104_STISTraight
Sensors Used:  
MPU6050 6-axis Accelerometer/Gyroscope
Hc-05

Motor Used:
Vibration Motor

## Installation Instructions
The project is a CCS Workspace. So just open it up in CCS.

### MPU6050 schematic
MPU6050 -- MSP432

  VCC   <-->  P6.0 For Power Cycling. VCC is fine too  
  GND   <-->  GND  
  SCL   <-->  P6.5 w/ 10k Pull Up Resistor  
  SDA   <-->  P6.4 w/ 10k Pull Up Resistor  
  XCA  
  XDA  
  ADO  
  INT  


### Note
Credit Armin for helping out with the MPU6050.