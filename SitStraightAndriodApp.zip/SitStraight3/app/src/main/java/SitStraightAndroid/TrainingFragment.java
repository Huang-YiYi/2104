package SitStraightAndroid;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import SitStraightAndroid.R;

public class TrainingFragment extends Fragment implements AdapterView.OnItemSelectedListener, ServiceConnection, SerialListener {

    private enum Connected { False, Pending, True }
    private String deviceAddress;
    private String newline = "\r\n";
    private TextView receiveText;
    private SerialSocket socket;
    private SerialService service;
    private boolean initialStart = true;
    private Connected connected = Connected.False;


    View view;
    TextView tv;
    TextView recommendation;
    Button btn_selectMonitor;
    EditText bodyPart;
    EditText et;
    EditText et2;
    Spinner spinner;
    private String item;
    TextView textView2;


    TextView tvDifficulty;
    TextView tvBodyPart;
    TextView tvAngle;
    TextView tvDuration;
    TextView labelDifficulty;
    TextView labelBodyPart;
    TextView labelAngle;
    TextView labelDuration;
    TextView textViewReading;
    Button btn_stopReading;
    Button btn_startReading;
    TextView tvTry;

    String setData = "";

    /*
     * Lifecycle
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
        deviceAddress = getArguments().getString("deviceAddress");
    }

    @Override
    public void onDestroy() {
        if (connected != Connected.False)
            disconnect();
        getActivity().stopService(new Intent(getActivity(), SerialService.class));
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        if(service != null)
            service.attach(this);
        else
            getActivity().startService(new Intent(getActivity(), SerialService.class)); // prevents service destroy on unbind from recreated activity caused by orientation change
    }

    @Override
    public void onStop() {
        if(service != null && !getActivity().isChangingConfigurations())
            service.detach();
        super.onStop();
    }

    @SuppressWarnings("deprecation") // onAttach(context) was added with API 23. onAttach(activity) works for all API versions
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        getActivity().bindService(new Intent(getActivity(), SerialService.class), this, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onDetach() {
        try { getActivity().unbindService(this); } catch(Exception ignored) {}
        super.onDetach();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(initialStart && service !=null) {
            initialStart = false;
            getActivity().runOnUiThread(this::connect);
        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder binder) {
        service = ((SerialService.SerialBinder) binder).getService();
        if(initialStart && isResumed()) {
            initialStart = false;
            getActivity().runOnUiThread(this::connect);
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        service = null;
    }



    /*
     * UI
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_terminal, container, false);
        recommendation = (TextView) view.findViewById(R.id.Recommendation);
        bodyPart = (EditText) view.findViewById(R.id.BodyPart);
        et = (EditText) view.findViewById(R.id.Angle);
        et2 = (EditText) view.findViewById(R.id.Duration);
        textView2 = (TextView) view.findViewById(R.id.textView2);

        receiveText = (TextView) view.findViewById(R.id.receive_text);                          // TextView performance decreases with number of spans
        receiveText.setTextColor(getResources().getColor(R.color.colorRecieveText)); // set as default color to reduce number of spans
        receiveText.setMovementMethod(ScrollingMovementMethod.getInstance());
        receiveText.setVisibility(View.GONE);


        //1st frame
        recommendation.setVisibility(View.GONE);
        et.setVisibility(View.GONE);
        et2.setVisibility(View.GONE);


        //second frame
        tvDifficulty = (TextView) view.findViewById(R.id.tvDifficulty);
        tvBodyPart = (TextView) view.findViewById(R.id.tvBodyPart);
        tvAngle = (TextView) view.findViewById(R.id.tvAngle);
        tvDuration = (TextView) view.findViewById(R.id.tvDuration);
        labelDifficulty = (TextView) view.findViewById(R.id.labelDifficulty);
        labelBodyPart = (TextView) view.findViewById(R.id.labelBodyPart);
        labelAngle = (TextView) view.findViewById(R.id.labelAngle);
        labelDuration = (TextView) view.findViewById(R.id.labelDuration);
        textViewReading = (TextView) view.findViewById(R.id.textViewReading);
        btn_stopReading = (Button) view.findViewById(R.id.btn_stopReading);
        btn_startReading = (Button) view.findViewById(R.id.btn_startReading);


        tvDifficulty.setVisibility(View.GONE);
        tvBodyPart.setVisibility(View.GONE);
        tvAngle.setVisibility(View.GONE);
        tvDuration.setVisibility(View.GONE);
        labelDifficulty.setVisibility(View.GONE);
        labelBodyPart.setVisibility(View.GONE);
        labelAngle.setVisibility(View.GONE);
        labelDuration.setVisibility(View.GONE);
        textViewReading.setVisibility(View.GONE);
        btn_stopReading.setVisibility(View.GONE);
        btn_startReading.setVisibility(View.GONE);


        // Spinner element
        spinner = (Spinner) view.findViewById(R.id.spinner);
        // Spinner click listener
        spinner.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("--Select Difficulty--");
        categories.add("Easy");
        categories.add("Medium");
        categories.add("Difficult");
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, categories);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);


        btn_selectMonitor = (Button) view.findViewById(R.id.btn_selectMonitor);
        btn_selectMonitor.setVisibility(View.GONE);
        btn_selectMonitor.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v)
            {
                setData = 'b' + et.getText().toString();
                send(setData);
                Toast.makeText(getActivity(), "Configuration has been set!",
                        Toast.LENGTH_LONG).show();


                //1st frame
                textView2.setVisibility(View.GONE);
                recommendation.setVisibility(View.GONE);
                et.setVisibility(View.GONE);
                et2.setVisibility(View.GONE);
                btn_selectMonitor.setVisibility(View.GONE);
                spinner.setVisibility(View.GONE);
                bodyPart.setVisibility(View.GONE);


                //2nd frame
                tvDifficulty.setVisibility(View.VISIBLE);
                tvBodyPart.setVisibility(View.VISIBLE);
                tvAngle.setVisibility(View.VISIBLE);
                tvDuration.setVisibility(View.VISIBLE);
                labelDifficulty.setVisibility(View.VISIBLE);
                labelBodyPart.setVisibility(View.VISIBLE);
                labelAngle.setVisibility(View.VISIBLE);
                labelDuration.setVisibility(View.VISIBLE);
                textViewReading.setVisibility(View.VISIBLE);
                btn_stopReading.setVisibility(View.VISIBLE);
                btn_startReading.setVisibility(View.VISIBLE);
                tvDifficulty.setText(item.toString());
                tvBodyPart.setText(bodyPart.getText().toString());
                tvAngle.setText(et.getText().toString()+(char) 0x00B0);
                tvDuration.setText(et2.getText().toString()+ "mins");

                receiveText.setVisibility(View.VISIBLE);


                //countdown duration
                long vals = (Long.parseLong(et2.getText().toString()))*1000;
                //countdown
                new CountDownTimer(vals, 1000)
                {
                    public void onTick(long millisUntilFinished) {

                    }

                    public void onFinish() {
                        send("ttt");
                        Toast.makeText(getActivity(), "Readings Stopped!",
                                Toast.LENGTH_LONG).show();
                    }
                }.start();
            }
        });

        btn_stopReading = (Button) view.findViewById(R.id.btn_stopReading);
        btn_stopReading.setVisibility(View.GONE);
        btn_stopReading.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v)
            {
                send("ttt");
            }
        });

        btn_startReading = (Button) view.findViewById(R.id.btn_startReading);
        btn_startReading.setVisibility(View.GONE);
        btn_startReading.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v)
            {
                send(setData);
            }
        });


        return view;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        // On selecting a spinner item
        item = parent.getItemAtPosition(position).toString();
        if (position == 1)
        {
            recommendation.setText("Recommended Angle for Neck: 15 degree \n Recommendated Duration for Neck: 10mins");
            recommendation.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
            recommendation.setTextColor(Color.YELLOW);

            et.setVisibility(View.VISIBLE);
            et2.setVisibility(View.VISIBLE);
            btn_selectMonitor.setVisibility(View.VISIBLE);
        }
        else if(position == 2)
        {
            recommendation.setText("Recommended Angle for Neck: 15 degree \n Recommendated Duration for Neck: 20mins");
            recommendation.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
            recommendation.setTextColor(Color.YELLOW);

            et.setVisibility(View.VISIBLE);
            et2.setVisibility(View.VISIBLE);
            btn_selectMonitor.setVisibility(View.VISIBLE);
        }
        else if(position == 3)
        {
            recommendation.setText("Recommended Angle for Neck: 15 degree \n Recommendated Duration for Neck: 30mins");
            recommendation.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
            recommendation.setTextColor(Color.YELLOW);

            et.setVisibility(View.VISIBLE);
            et2.setVisibility(View.VISIBLE);
            btn_selectMonitor.setVisibility(View.VISIBLE);
        }
        recommendation.setVisibility(View.VISIBLE);


    }
    public void onNothingSelected(AdapterView<?> arg0)
    {
        recommendation.setVisibility(View.GONE);
        et.setVisibility(View.GONE);
        et2.setVisibility(View.GONE);
        btn_selectMonitor.setVisibility(View.GONE);

    }


    /*
     * Serial + UI
     */
    private void connect() {
        try {
            BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
            String deviceName = device.getName() != null ? device.getName() : device.getAddress();
            status("connecting...");
            connected = Connected.Pending;
            socket = new SerialSocket();
            service.connect(this, "Connected to " + deviceName);
            socket.connect(getContext(), service, device);
        } catch (Exception e) {
            onSerialConnectError(e);
        }
    }

    private void disconnect() {
        connected = Connected.False;
        service.disconnect();
        socket.disconnect();
        socket = null;
    }

    private void send(String str) {
        if(connected != Connected.True) {
            Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            //SpannableStringBuilder spn = new SpannableStringBuilder(str+'\n');
            //spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorSendText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            //receiveText.append(spn);
            byte[] data = (str + newline).getBytes();
            socket.write(data);
        } catch (Exception e) {
            onSerialIoError(e);
        }
    }

    private void receive(byte[] data) {
        receiveText.append(new String(data));
//        SpannableStringBuilder spn = new SpannableStringBuilder(new String(data));
//        //spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorOverLimit)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//
//        String value = receiveText.getText().toString();
//        try {
//            int num = Integer.parseInt(value);
//            Toast.makeText(getActivity(), String.valueOf(num),
//                       Toast.LENGTH_LONG).show();
////            if (num>30){
////                spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorOverLimit)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
////                receiveText.append(spn);
////            }
////        else {
////                receiveText.append(spn);
////            }
//        } catch(NumberFormatException nfe) {}

//        private void receive(byte[] data)
//        {
//        //receiveText.append(new String(data));
//        SpannableStringBuilder spn = new SpannableStringBuilder(new String(data));
//        //spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorOverLimit)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//
//        try {
//            String value = new String(data);
//            int num = Integer.parseInt(value);
//            Toast.makeText(getActivity(), String.valueOf(num),
//                       Toast.LENGTH_LONG).show();
//            receiveText.append(spn);
////            if (num>0){
////                spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorOverLimit)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
////                receiveText.append(spn);
////            }
////        else {
////                receiveText.append(spn);
////             }
//        } catch(NumberFormatException nfe) {}




    }

//    private void status2(String str) {
//        SpannableStringBuilder spn = new SpannableStringBuilder(str+'\n');
//        if (Integer.parseInt(str)>30){
//            spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorOverLimit)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//            receiveText.append(spn);
//        }
//        else{
//            receiveText.append(spn);
//        }
//
//    }

    private void status(String str) {
        SpannableStringBuilder spn = new SpannableStringBuilder(str+'\n');
        spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorStatusText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        receiveText.append(spn);
    }

    /*
     * SerialListener
     */
    @Override
    public void onSerialConnect() {
        status("connected");
        connected = Connected.True;
    }

    @Override
    public void onSerialConnectError(Exception e) {
        status("connection failed: " + e.getMessage());
        disconnect();
    }

    @Override
    public void onSerialRead(byte[] data) {
        receive(data);
    }

    @Override
    public void onSerialIoError(Exception e) {
        status("connection lost: " + e.getMessage());
        disconnect();
    }

}
