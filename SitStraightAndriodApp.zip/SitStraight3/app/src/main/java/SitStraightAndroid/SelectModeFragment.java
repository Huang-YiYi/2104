package SitStraightAndroid;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class SelectModeFragment extends Fragment
{

    View view;
    TextView tv;
    Button bn;
    private TextView receiveText;
    private String deviceAddress;
    int counter;
    volatile boolean stopWorker;

    /*
     * Lifecycle
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
        deviceAddress = getArguments().getString("device");
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_select_mode, container, false);
        tv = (TextView) view.findViewById(R.id.textView2);

        receiveText = view.findViewById(R.id.receive_text);                          // TextView performance decreases with number of spans
        receiveText.setTextColor(getResources().getColor(R.color.colorRecieveText)); // set as default color to reduce number of spans

        Button buttonselectTraining = (Button) view.findViewById(R.id.btn_selectTraining);
        buttonselectTraining.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                Bundle args = new Bundle();
                args.putString("deviceAddress", deviceAddress);
                Fragment fragment = new TrainingFragment();
                fragment.setArguments(args);
                getFragmentManager().beginTransaction().replace(R.id.fragment, fragment, "selectTraining").addToBackStack(null).commit();
            }
        });

        Button buttonselectMonitor = (Button) view.findViewById(R.id.btn_selectMonitor);
        buttonselectMonitor.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                // TODO Auto-generated method stub
                Bundle args2 = new Bundle();
                args2.putString("deviceAddress2", deviceAddress);
                Fragment fragment2 = new MonitorFragment();
                fragment2.setArguments(args2);
                getFragmentManager().beginTransaction().replace(R.id.fragment, fragment2, "selectMonitor").addToBackStack(null).commit();
            }
        });

        return view;
    }
}
